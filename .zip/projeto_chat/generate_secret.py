# parte 1
#  Criar uma chave segura  para o SECRET_KEY, no arquivo .env

import secrets

def main():
    print("🔐 Gerador de SECRET_KEY")
    print("=" * 40)
    
    chave = secrets.token_hex(24)
    
    print("Sua SECRET_KEY segura:")
    print(chave)
    print()
    print("Cole no seu arquivo .env:")
    print(f"SECRET_KEY={chave}")

if __name__ == "__main__":
    main()